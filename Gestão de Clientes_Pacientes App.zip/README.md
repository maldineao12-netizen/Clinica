# HealthCare CRM - Sistema de Gestão de Pacientes

Sistema completo de gestão de clientes/pacientes para clínicas, desenvolvido com React, TypeScript, Tailwind CSS e Supabase.

## Funcionalidades

### 🔐 Autenticação e Controle de Acesso
- Login seguro com Supabase Auth
- Cadastro de novos usuários com seleção de tipo
- **Dois tipos de usuários:**
  - **Administrador**: Acesso total ao sistema incluindo gestão de usuários
  - **Médico**: Acesso a pacientes e agendamentos
- Recuperação de senha
- Proteção de rotas privadas
- Controle de permissões baseado em roles

### 📊 Dashboard
- Visão geral com estatísticas em tempo real
- Total de pacientes cadastrados
- Agendamentos do dia
- Agendamentos por status (agendados, concluídos)
- Cards informativos com ícones e cores temáticas

### 👥 Gestão de Pacientes
- Lista completa de pacientes com cards responsivos
- Busca por nome, Bilhete de Identidade, email ou telefone
- Cadastro de novos pacientes com validação
- Edição de dados dos pacientes
- Visualização detalhada de informações
- Exclusão de pacientes
- Campos incluem: nome, Bilhete de Identidade, telefone, email, endereço, data de nascimento, histórico médico
- Exportação de dados em CSV ou JSON

### 📅 Sistema de Agendamentos
- Lista de agendamentos com filtros por status
- Criação de novos agendamentos
- Edição de agendamentos existentes
- Exclusão de agendamentos
- Seleção de pacientes cadastrados
- Status: Agendado, Concluído, Cancelado
- Tipos: Consulta, Retorno, Exame, Procedimento, Outro
- Campos: data, horário, duração, observações
- Visualização organizada por data
- Exportação de dados em CSV ou JSON

### 🔍 Busca Global
- Busca unificada no header
- Pesquisa em pacientes e agendamentos
- Resultados em tempo real
- Interface intuitiva com categorização

### 👥 Gestão de Usuários (Apenas Admin)
- Lista completa de usuários do sistema
- Alteração de tipo de usuário (Admin/Médico)
- Exclusão de usuários
- Visualização de informações de cadastro
- Badge visual indicando o tipo de cada usuário

### 🎨 Design e UX
- Interface moderna e limpa
- Dark Mode completo
- Totalmente responsivo (desktop, tablet, mobile)
- Animações suaves com Motion
- Toast notifications para feedback
- Loading states em todas as operações
- Sidebar responsiva com menu mobile
- Gradientes e sombras modernas
- Componentes UI do Radix UI

## Tecnologias Utilizadas

### Frontend
- **React 18** - Biblioteca JavaScript
- **TypeScript** - Tipagem estática
- **Tailwind CSS v4** - Framework CSS
- **Motion (Framer Motion)** - Animações
- **Radix UI** - Componentes acessíveis
- **Sonner** - Toast notifications
- **date-fns** - Manipulação de datas
- **Zod** - Validação de dados

### Backend
- **Supabase** - Backend as a Service
- **Supabase Auth** - Autenticação
- **Deno Edge Functions** - Serverless functions
- **Hono** - Framework web para Deno
- **PostgreSQL** - Banco de dados (via Supabase)

## Estrutura do Projeto

```
src/
├── app/
│   ├── components/
│   │   ├── auth/          # Componentes de autenticação
│   │   ├── dashboard/     # Dashboard principal
│   │   ├── patients/      # Gestão de pacientes
│   │   ├── appointments/  # Sistema de agendamentos
│   │   ├── search/        # Busca global
│   │   ├── layout/        # Layout e navegação
│   │   └── ui/            # Componentes UI base
│   ├── contexts/          # Contextos React (Auth)
│   ├── lib/               # Utilitários e configurações
│   ├── utils/             # Funções auxiliares
│   └── App.tsx            # Componente principal
├── supabase/
│   └── functions/
│       └── server/        # Backend Edge Functions
├── utils/
│   └── supabase/          # Configurações Supabase
└── styles/                # Estilos globais
```

## Backend API

### Endpoints Disponíveis

#### Autenticação
- `POST /make-server-0418aac9/auth/signup` - Criar nova conta (requer: email, password, name, role)

#### Gestão de Usuários (Admin apenas)
- `GET /make-server-0418aac9/users` - Listar todos os usuários
- `PUT /make-server-0418aac9/users/:id/role` - Atualizar role de um usuário
- `DELETE /make-server-0418aac9/users/:id` - Excluir um usuário

#### Pacientes
- `GET /make-server-0418aac9/patients` - Listar todos os pacientes
- `GET /make-server-0418aac9/patients/:id` - Buscar paciente específico
- `POST /make-server-0418aac9/patients` - Criar novo paciente
- `PUT /make-server-0418aac9/patients/:id` - Atualizar paciente
- `DELETE /make-server-0418aac9/patients/:id` - Excluir paciente

#### Agendamentos
- `GET /make-server-0418aac9/appointments` - Listar todos os agendamentos
- `POST /make-server-0418aac9/appointments` - Criar novo agendamento
- `PUT /make-server-0418aac9/appointments/:id` - Atualizar agendamento
- `DELETE /make-server-0418aac9/appointments/:id` - Excluir agendamento

#### Estatísticas
- `GET /make-server-0418aac9/stats` - Obter estatísticas do dashboard

Todos os endpoints (exceto signup) requerem autenticação via header `Authorization: Bearer <access_token>`.

## Armazenamento de Dados

O sistema utiliza o **Supabase KV Store** (key-value store) com a tabela `kv_store_0418aac9` para armazenar:
- Dados dos usuários
- Informações dos pacientes
- Agendamentos

Padrão de chaves:
- `user:{userId}` - Dados do usuário
- `patient:{userId}:{patientId}` - Dados do paciente
- `appointment:{userId}:{appointmentId}` - Dados do agendamento

## Como Usar

1. **Primeiro acesso**: Crie uma conta usando o formulário de cadastro
   - Escolha o tipo de usuário: **Administrador** ou **Médico**
   - Administradores têm acesso total ao sistema
2. **Login**: Entre com email e senha
3. **Dashboard**: Visualize as estatísticas gerais
4. **Pacientes**: Navegue até a seção de pacientes para cadastrar e gerenciar
5. **Agendamentos**: Crie agendamentos selecionando pacientes cadastrados
6. **Usuários** (Admin): Gerencie usuários do sistema, altere permissões e exclua contas
7. **Busca**: Use a busca global no header para encontrar rapidamente
8. **Exportação**: Exporte dados em CSV ou JSON nas páginas de pacientes e agendamentos
9. **Dark Mode**: Alterne entre tema claro e escuro usando o botão no header

## Tipos de Usuário

### Administrador
- Acesso completo ao sistema
- Gestão de usuários (criar, editar, excluir)
- Gestão de pacientes
- Gestão de agendamentos
- Visualização de estatísticas
- Badge distintivo no sidebar

### Médico
- Gestão de pacientes
- Gestão de agendamentos
- Visualização de estatísticas
- Sem acesso à gestão de usuários

## Validações e Segurança

- Validação de formulários em tempo real
- Campos obrigatórios marcados com *
- Autenticação JWT via Supabase
- Proteção de rotas privadas
- Middleware de autenticação no backend
- CORS configurado corretamente
- Dados isolados por usuário

## Responsividade

O sistema é totalmente responsivo e funciona perfeitamente em:
- Desktop (1920px+)
- Laptop (1024px - 1920px)
- Tablet (768px - 1024px)
- Mobile (< 768px)

## Performance

- Loading states em todas as operações
- Debounce na busca global (300ms)
- Animações otimizadas com Motion
- Componentes lazy quando necessário

## Desenvolvido com

Este projeto foi desenvolvido usando Figma Make, uma plataforma para criação rápida de aplicações web modernas.
